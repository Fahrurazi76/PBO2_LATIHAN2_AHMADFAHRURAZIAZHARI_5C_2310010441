# Aplikasi Hitung Umur

Aplikasi GUI sederhana berbasis Java untuk menghitung umur berdasarkan tanggal lahir yang dipilih menggunakan `JDateChooser`.

## Fitur
- Input tanggal lahir melalui kalender (`JDateChooser`)
- Menampilkan umur dalam tahun, bulan, dan hari
- Menampilkan tanggal ulang tahun berikutnya dan berapa hari lagi

## Cara Menjalankan di NetBeans
1. Buka NetBeans → File → Open Project → pilih folder `AplikasiHitungUmur`
2. Klik kanan project → Properties → Libraries → Add JAR/Folder
3. Tambahkan file `jcalendar-1.4.jar` ke folder `lib/`
4. Jalankan program (`Shift + F6`)

## Download JCalendar
🔗 https://toedter.com/jcalendar/

