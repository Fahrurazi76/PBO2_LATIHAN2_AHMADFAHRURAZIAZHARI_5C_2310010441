import javax.swing.*;
import com.toedter.calendar.JDateChooser;
import java.awt.event.*;
import java.time.*;
import java.time.temporal.ChronoUnit;

public class HitungUmur extends JFrame {
    private JDateChooser dateChooser;
    private JButton btnHitung;
    private JTextField txtUmur, txtUlangTahun;
    private JLabel lblTanggal, lblUmur, lblUlangTahun;

    public HitungUmur() {
        setTitle("Aplikasi Hitung Umur");
        setSize(400, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        lblTanggal = new JLabel("Pilih Tanggal Lahir:");
        lblTanggal.setBounds(30, 30, 150, 25);
        add(lblTanggal);

        dateChooser = new JDateChooser();
        dateChooser.setBounds(180, 30, 150, 25);
        add(dateChooser);

        lblUmur = new JLabel("Umur Anda:");
        lblUmur.setBounds(30, 80, 150, 25);
        add(lblUmur);

        txtUmur = new JTextField();
        txtUmur.setBounds(180, 80, 180, 25);
        txtUmur.setEditable(false);
        add(txtUmur);

        lblUlangTahun = new JLabel("Ulang Tahun Berikutnya:");
        lblUlangTahun.setBounds(30, 120, 180, 25);
        add(lblUlangTahun);

        txtUlangTahun = new JTextField();
        txtUlangTahun.setBounds(180, 120, 180, 25);
        txtUlangTahun.setEditable(false);
        add(txtUlangTahun);

        btnHitung = new JButton("Hitung");
        btnHitung.setBounds(140, 170, 100, 30);
        add(btnHitung);

        btnHitung.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (dateChooser.getDate() != null) {
                    LocalDate tglLahir = dateChooser.getDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                    LocalDate sekarang = LocalDate.now();

                    Period p = Period.between(tglLahir, sekarang);
                    txtUmur.setText(p.getYears() + " tahun, " + p.getMonths() + " bulan, " + p.getDays() + " hari");

                    LocalDate nextBirthday = tglLahir.withYear(sekarang.getYear());
                    if (!nextBirthday.isAfter(sekarang)) {
                        nextBirthday = nextBirthday.plusYears(1);
                    }
                    long daysUntil = ChronoUnit.DAYS.between(sekarang, nextBirthday);
                    txtUlangTahun.setText(nextBirthday.toString() + " (" + daysUntil + " hari lagi)");
                } else {
                    JOptionPane.showMessageDialog(null, "Silakan pilih tanggal lahir terlebih dahulu.");
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new HitungUmur().setVisible(true);
            }
        });
    }
}
